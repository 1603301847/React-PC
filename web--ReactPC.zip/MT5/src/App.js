import React from 'react';
import HOME from './home'; 

function App() {
  return (
    <div className="App">
        <HOME />
    </div>
  );
}

export default App;
