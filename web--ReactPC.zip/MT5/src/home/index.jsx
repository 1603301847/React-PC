


import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import { Layout } from 'antd';
import { Menu, Icon } from 'antd';

import Home from './home';
import CsvToJsonPage from 'chart/csvToJson';
import GetJsonPage from 'chart/getJson';
import ComputedPage from 'computed/index';
import PicturePage from 'picture/index';




const { Sider, Content } = Layout;
const { SubMenu } = Menu;


class HomeHTML extends Component {

    constructor(props) {
        super(props);
        this.state={
            bodyHeight:document.body.clientHeight,
        };
    }

    render() {
        let {bodyHeight} = this.state;

        return <Router>
            <Layout>
                <Sider>
                    <Menu defaultOpenKeys={['menu1']} style={{height:bodyHeight-30,width:180}} mode="inline">
                        <SubMenu
                            key="menu1"
                            title={
                                <Link to="/">
                                    <span>
                                        <Icon type="api" />
                                        <span>
                                            chart
                                        </span>
                                    </span>
                                </Link>
                            }
                        >
                            
                            <Menu.Item key="1">
                                <Link to="/CsvToJsonPage">CSV->Json</Link>
                            </Menu.Item>
                            <Menu.Item key="2">
                                <Link to="/GetJsonPage">statistics</Link>
                            </Menu.Item>
                            <Menu.Item key="3">
                                <Link to="/ComputedPage">computedPage</Link>
                            </Menu.Item>
                            <Menu.Item key="4">
                                <Link to="/Picture">picture</Link>
                            </Menu.Item>
                            
                        </SubMenu>
                    </Menu>
                </Sider>



                <Content>
                        {/*
                            A <Switch> looks through all its children <Route>
                            elements and renders the first one whose path
                            matches the current URL. Use a <Switch> any time
                            you have multiple routes, but you want only one
                            of them to render at a time
                        */}
                    <Switch>
                        <Route exact path="/">
                            <Home />
                        </Route>
                        <Route path="/CsvToJsonPage">
                            <CsvToJsonPage />
                        </Route>
                        <Route path="/GetJsonPage">
                            <GetJsonPage />
                        </Route>     
                        <Route path="/ComputedPage">
                            <ComputedPage />
                        </Route> 
                        <Route path="/Picture">
                            <PicturePage />   
                        </Route> 
                    </Switch>
                </Content>
            </Layout>
        </Router>      
    }
}

export default HomeHTML; 