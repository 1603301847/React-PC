import React, { Component } from 'react';

class BodyHTML extends Component {

    constructor(props) {
        super(props);
        this.state={};
    }

    render() {
        return <div>
            <h3 style={{fontFamily:'cursive',fontWeight:'bold',fontStyle:'italic',fontSize:'27px'}}>Oh captain my captain!</h3>
        </div>
    }
}

export default BodyHTML; 